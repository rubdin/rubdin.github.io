$(function () { 
	
})

$(document).ready(function () { 
	$('.bxslider').bxSlider({
		mode: 'fade',
		infiniteLoop: true,
		speed: 500,
		slideMargin: 0,
		captions: true,
		pager: true, 
		pagerType: 'full',
		autoControls: true,
	})
})
